node filter.spec3 ./submissions/Adam\ Yahid/filter_engine.js
node filter.spec3 ./submissions/Aleksandrs\ Fiļipovs/filter.js
node filter.spec3 ./submissions/Aleksei\ Murashin/filter.js
node filter.spec3 ./submissions/Aleksey\ Sergey/filter.js
node filter.spec3 ./submissions/Alex\ Kheben/filter.js
node filter.spec3 ./submissions/Alex\ Ku/filter.js
node filter.spec3 ./submissions/Alex\ Netkachov/filter.js
node filter.spec3 ./submissions/Alex\ Vishnevsky/filter.js
node filter.spec3 ./submissions/Alexander\ Baygeldin/filter_fsa.js
node filter.spec3 ./submissions/Alexander\ Dubovsky/filters.js
node filter.spec3 ./submissions/Alexander\ Hasselbach/hola-filter.js
node filter.spec3 ./submissions/Alexander\ Ilyin/filter2.js
node filter.spec3 ./submissions/Alexander\ Kazachenko/index.js
node filter.spec3 ./submissions/Alexander\ Nurullov/filtr.js
node filter.spec3 ./submissions/Alexander\ Oryol/mailFilter.js
node filter.spec3 ./submissions/Alexander\ Rusakov/filter.js
node filter.spec3 ./submissions/Alexander\ Savchuk/solution.js
node filter.spec3 ./submissions/Alexander\ Zasim/filter.js
node filter.spec3 ./submissions/Alexandr/filter.js
node filter.spec3 ./submissions/Alexey\ Alexandrovich/filter.min.js
node filter.spec3 ./submissions/Alexey\ Chemichev/achemichevfilterR2.js
node filter.spec3 ./submissions/Alexey\ Diyachenko/filter.js
node filter.spec3 ./submissions/Alexey\ Efremov/index.js
node filter.spec3 ./submissions/Alexey\ Gora/filter.js
node filter.spec3 ./submissions/Alexey\ Kolpakov/filter10.js
node filter.spec3 ./submissions/Alexey\ Larkov/filter.js
node filter.spec3 ./submissions/Alexey\ Nichiporchik/filter.js
node filter.spec3 ./submissions/Alexey\ Pushnikov/filter.js
node filter.spec3 ./submissions/Alexey\ Sadovin/filter.js
node filter.spec3 ./submissions/Alexey\ Semashkevich/filter.js
node filter.spec3 ./submissions/Alexey\ Vedyakov/compiled.js
node filter.spec3 ./submissions/Alina\ Lozhkina/filter.js
node filter.spec3 ./submissions/Almaz\ Mubinov/filter.js
node filter.spec3 ./submissions/Amir\ Absalyamov/filter.js
node filter.spec3 ./submissions/Anatoly/filter.js
node filter.spec3 ./submissions/Andrew\ Kashta/filter.js
node filter.spec3 ./submissions/Andrey\ Chernykh/filter.js
node filter.spec3 ./submissions/Andrey\ Grankin/filter.js
node filter.spec3 ./submissions/Andrey\ Kostakov/challenge_mail_filter.js
node filter.spec3 ./submissions/Andrey\ Kuznetsov/index.js
node filter.spec3 ./submissions/Andrey\ Pogoreltsev/filter.js
node filter.spec3 ./submissions/Andrey\ Saponenko/filter.js
node filter.spec3 ./submissions/Andrey\ Solodovnikov/filter.js
node filter.spec3 ./submissions/Andy5938/filterAndy5938.js
node filter.spec3 ./submissions/Anton\ Ivakin/filter.js
node filter.spec3 ./submissions/Anton\ Podkuyko/index.js
node filter.spec3 ./submissions/Anton\ Vashurkin/index.js
node filter.spec3 ./submissions/Arkadi\ Klepatch/filter.js
node filter.spec3 ./submissions/Artem\ Kudryavtsev/mailfilter.js
node filter.spec3 ./submissions/Artem\ Mitloshuk/Artem_Mitloshuk_JS_Challenge.js
node filter.spec3 ./submissions/Arthur\ Khusaenov/filter.js
node filter.spec3 ./submissions/Arthur\ Okeke/filter.js
node filter.spec3 ./submissions/Aydar\ Mirzagitov/filter.js
node filter.spec3 ./submissions/berrunder/filter.js
node filter.spec3 ./submissions/Bilik\ Sandanov/filter.js
node filter.spec3 ./submissions/Black\ Knight/result.js
node filter.spec3 ./submissions/Dan\ Revah/filter-optimized.js
node filter.spec3 ./submissions/Daniel\ Shir/filter5.js
node filter.spec3 ./submissions/Daniil\ Onoshko/filter.js
node filter.spec3 ./submissions/Danil\ Baibak/filter.js
node filter.spec3 ./submissions/Danila\ Sukhanov/filter.js
node filter.spec3 ./submissions/Denis\ Bezrukov/filter.js
node filter.spec3 ./submissions/Denis\ Bogomoltsev/filter.js
node filter.spec3 ./submissions/Denis\ Karavayev/filter.js
node filter.spec3 ./submissions/Denis\ Kepeshchuk/filter.js
node filter.spec3 ./submissions/Denis\ Kreshikhin/kreshikhin-filter.js
node filter.spec3 ./submissions/Denis\ Maslov/filter.js
node filter.spec3 ./submissions/Denis\ Protasov/filter.js
node filter.spec3 ./submissions/Denis\ Zakharov/dist\ \ src
node filter.spec3 ./submissions/Denys\ Skychko/filter.js
node filter.spec3 ./submissions/Dilshod\ Samatov/mail_utility.js
node filter.spec3 ./submissions/disamis/filter.js
node filter.spec3 ./submissions/Dizzy\ D/filter.js
node filter.spec3 ./submissions/Dmitry\ Egorov/degorov.js
node filter.spec3 ./submissions/Dmitry\ Fedoryak/filter10.js
node filter.spec3 ./submissions/Dmitry\ Kurochkin/filter.js
node filter.spec3 ./submissions/Dmitry\ Petrov/filter.js
node filter.spec3 ./submissions/Dmitry\ Poddubniy/filterV1.js
node filter.spec3 ./submissions/Dmitry\ Podgorniy/filter.js
node filter.spec3 ./submissions/Dmitry\ Rybin/index.js
node filter.spec3 ./submissions/Dmitry\ Soloviev/3.js
node filter.spec3 ./submissions/Dmitry\ Tarasenko/index.js
node filter.spec3 ./submissions/Dzmitry\ Ulasiankou/MailFilter.js
node filter.spec3 ./submissions/Ecma\ Scripter/filter.js
node filter.spec3 ./submissions/Elshad\ Shirinov/impl.js
node filter.spec3 ./submissions/Evgenii\ Kazmiruk/filter.js
node filter.spec3 ./submissions/Evgeny\ Frolov/filter.js
node filter.spec3 ./submissions/Evgeny\ Khramkov/filter.js
node filter.spec3 ./submissions/Evgeny\ Lukianchikov/filter.js
node filter.spec3 ./submissions/Evgeny\ Olonov/index.js
node filter.spec3 ./submissions/Evgeny\ Semyonov/filter.js
node filter.spec3 ./submissions/Evgeny\ Shiryaev/filter.js
node filter.spec3 ./submissions/Evgeny\ Zeyler/filter.js
node filter.spec3 ./submissions/fb5813a09c0f95242cb/filter.js
node filter.spec3 ./submissions/Georgy\ Chebanov/filter.js
node filter.spec3 ./submissions/Grigory\ Alexeev/Alexeev\ Grigorii\ -\ MailFiltering.js
node filter.spec3 ./submissions/Grigory\ Plotnikov/filter.js
node filter.spec3 ./submissions/Guy\ Brukhis/hola_challenge_mail_filter.js
node filter.spec3 ./submissions/Guy\ Rapaport/mail_filter.js
node filter.spec3 ./submissions/Haim\ Kom/filter.js
node filter.spec3 ./submissions/happymarmoset/filter.js
node filter.spec3 ./submissions/Hayk\ Martirosyan/app.js
node filter.spec3 ./submissions/Hongliang\ Wang/hongliang.js
node filter.spec3 ./submissions/Ice\ Kibitzer/filter.js
node filter.spec3 ./submissions/Ido\ Ran/filter.js
node filter.spec3 ./submissions/Igal\ Miroshnichenko/filter.js
node filter.spec3 ./submissions/Igor\ Klopov/klopov-02-solve-corasick-O3.js
node filter.spec3 ./submissions/Igor\ Malanyk/filter.js
node filter.spec3 ./submissions/Igor\ Potapov/filter.js
node filter.spec3 ./submissions/Igor\ Vladimirovich/hola.js
node filter.spec3 ./submissions/Ihor\ Barakaiev\ and\ Dmitry\ Karaush/hola.js
node filter.spec3 ./submissions/Ihor\ Barakaiev\ and\ Dmitry\ Karaush/non-regex.js
node filter.spec3 ./submissions/Ilya\ Chervonov/ichervon.js
node filter.spec3 ./submissions/Ilya\ Gelman/index.js
node filter.spec3 ./submissions/Ilya\ Kirichek/volkswagen.js
node filter.spec3 ./submissions/Ilya\ Makarov/filter-with-memo.js
node filter.spec3 ./submissions/Ilya\ Mochalov/index.js
node filter.spec3 ./submissions/Ionicman/check.js
node filter.spec3 ./submissions/Itay\ Komemy/sol.js
node filter.spec3 ./submissions/Ivan\ Lukashov/mail.js
node filter.spec3 ./submissions/Ivan\ Maltsev/filter.js
node filter.spec3 ./submissions/Ivan\ Nikitin/filter.js
node filter.spec3 ./submissions/Ivan\ Saloid/contest.js
node filter.spec3 ./submissions/Ivan\ Zakharchenko/filter.js
node filter.spec3 ./submissions/Jarek\ Płocki/filter.js
node filter.spec3 ./submissions/Jean-Philippe\ Gauthier/MailFilteringEngine.js
node filter.spec3 ./submissions/jsmeister/filter.js
node filter.spec3 ./submissions/Katerina\ Pavlenko/filter.js
node filter.spec3 ./submissions/Kazim/filter.js
node filter.spec3 ./submissions/Kedem\ Diamant/filter.js
node filter.spec3 ./submissions/KingOfNothing/kingofnothing_filter.js
node filter.spec3 ./submissions/Kirill\ Bykov/script.js
node filter.spec3 ./submissions/Kirill\ Yakovlev/filter.js
node filter.spec3 ./submissions/Kobi/filter_v2.js
node filter.spec3 ./submissions/Konstantin\ Boyandin/mail_filter.js
node filter.spec3 ./submissions/Konstantin\ Petryaev/hola8.js
node filter.spec3 ./submissions/Kwek\ Jing\ Yang/filter.js
node filter.spec3 ./submissions/Lee\ Elenbaas/mail-filter.js
node filter.spec3 ./submissions/Leonid\ Kuznetsov/filter.js
node filter.spec3 ./submissions/madshall/index.js
node filter.spec3 ./submissions/MakarovEm/mailfilter.js
node filter.spec3 ./submissions/Maksim\ Razumenko/filter.js
node filter.spec3 ./submissions/Mark\ Gubarev/filter.js
node filter.spec3 ./submissions/Max\ Brodin/filter.js
node filter.spec3 ./submissions/Max\ Leizerovich/mail-filter.attempt1.js
node filter.spec3 ./submissions/Maxim\ Drozdov/filter.js
node filter.spec3 ./submissions/Maxim\ Khoruzhko/filter.js
node filter.spec3 ./submissions/Moshe\ Revah/index.js
node filter.spec3 ./submissions/mycodef/index.js
node filter.spec3 ./submissions/Nadav\ Ivgi/filter.js
node filter.spec3 ./submissions/nerv/filter.js
node filter.spec3 ./submissions/Nickolay\ Savchenko/filter.js
node filter.spec3 ./submissions/Nikita\ Isaev/filter.js
node filter.spec3 ./submissions/Nikita\ Molostvov/filter.js
node filter.spec3 ./submissions/Nikita\ Polevoy/filter.js
node filter.spec3 ./submissions/Nikolay\ Karev/karevn.js
node filter.spec3 ./submissions/Nikolay\ Kuchumov/filter.js
node filter.spec3 ./submissions/Nikolay\ Olonov/index.js
node filter.spec3 ./submissions/Nikolay\ Shevlyakov/filter.js
node filter.spec3 ./submissions/Nurguly\ Ashyrov/Filter.js
node filter.spec3 ./submissions/Oleg\ Panchenko/filter.js
node filter.spec3 ./submissions/Oleg\ Popov/filter.js
node filter.spec3 ./submissions/Oleh\ Tsiroh/filter.js
node filter.spec3 ./submissions/Oleksandr\ Antonyuk/filter.js
node filter.spec3 ./submissions/Ori\ Lahav/mailfilterv1.js
node filter.spec3 ./submissions/Ouanalao/filter.js
node filter.spec3 ./submissions/Oz\ GabsoZ/filter.js
node filter.spec3 ./submissions/Oz\ Shapira/mail_filter.js
node filter.spec3 ./submissions/Pavel\ Gruba/filter.js
node filter.spec3 ./submissions/Pavel\ Koltyshev/index.js
node filter.spec3 ./submissions/Pavel\ Orlov/filter.js
node filter.spec3 ./submissions/Pavel\ Pogodaev/holaemail.js
node filter.spec3 ./submissions/Pavel\ Polyakov/index.js
node filter.spec3 ./submissions/Pavel\ Tomsha/filter.js
node filter.spec3 ./submissions/Petr\ Shalkov/filter.js
node filter.spec3 ./submissions/Pham\ Vu\ Tuan/PhamVuTuan_HolaJS.js
node filter.spec3 ./submissions/poluyanov/messageFilter.js
node filter.spec3 ./submissions/Ptax/filter.js
node filter.spec3 ./submissions/qeled/filter.js
node filter.spec3 ./submissions/R5t4nah6/filter.js
node filter.spec3 ./submissions/Raoul\ Foaleng/example.js
node filter.spec3 ./submissions/Roman\ Pletnev/roman_pletnev_filter.js
node filter.spec3 ./submissions/Roman\ Timashev/filter.js
node filter.spec3 ./submissions/Rostislav\ Galkin/filter.js
node filter.spec3 ./submissions/Ruslan\ Bekenev/filter.js
node filter.spec3 ./submissions/Ruslan\ Koptev/filter-regexp.js
node filter.spec3 ./submissions/Ruslan\ Minukov/filter.js
node filter.spec3 ./submissions/Sashko\ Matviychuk/filter.js
node filter.spec3 ./submissions/Sergey\ Golub/filter.js
node filter.spec3 ./submissions/Sergey\ Ivanov/filter.js
node filter.spec3 ./submissions/Sergey\ Kluchkovsky/filter.js
node filter.spec3 ./submissions/Sergey\ Lichack/filter.js
node filter.spec3 ./submissions/Sergey\ Mikhailovich/filter.js
node filter.spec3 ./submissions/Sergey\ Petkun/filter_final.js
node filter.spec3 ./submissions/Sergey\ Savelyev/filter.js
node filter.spec3 ./submissions/Sergey\ Serebryakov/filtermail.js
node filter.spec3 ./submissions/Sergey\ Tolok/filter.js
node filter.spec3 ./submissions/Sergii\ Iakymov/filter.js
node filter.spec3 ./submissions/Sergius\ Galjuk/Sergius_challenge_winter_2015.js
node filter.spec3 ./submissions/Serhiy\ Mitrovtsiy/hola.js
node filter.spec3 ./submissions/Serj\ Karasev/mailfilter_serjkarasev.js
node filter.spec3 ./submissions/serviceman/index.js
node filter.spec3 ./submissions/Shantanu\ Gupta/filtering_engine.js
node filter.spec3 ./submissions/Siroj\ Matchanov/msn.js
node filter.spec3 ./submissions/Slava\ Shklyaev/filter.js
node filter.spec3 ./submissions/Stanislav\ Vyshchepan/filter.js\ \ filter.ts
node filter.spec3 ./submissions/Stas\ Vasilyev/filter_stanislav.js
node filter.spec3 ./submissions/Stepan\ Pupkin/solA.js
node filter.spec3 ./submissions/taitulism/filter.js
node filter.spec3 ./submissions/Tan\ Ying\ Hao/HolaJS.js
node filter.spec3 ./submissions/Taras\ Ozarko/index.js
node filter.spec3 ./submissions/Timophey\ Nakhai/the_best_one.js
node filter.spec3 ./submissions/Valeriy\ Petlya/filter.js
node filter.spec3 ./submissions/Vasiliy\ Kostin/filter.js
node filter.spec3 ./submissions/Victor\ Follet/filters.js
node filter.spec3 ./submissions/Vitali\ Falileev/hola_filter.js
node filter.spec3 ./submissions/Vitali\ Koshtoev/filter.js
node filter.spec3 ./submissions/Vitalii\ Petrychuk/index.js
node filter.spec3 ./submissions/Vitaliy\ \(vint\)/filter.js
node filter.spec3 ./submissions/Vitaliy\ Sunny/string-prototype-switch.js
node filter.spec3 ./submissions/Vitaly\ Domnikov/nutcracker.js
node filter.spec3 ./submissions/Vitaly\ Dyatlov/filter.js
node filter.spec3 ./submissions/Vladimir\ Barbarosh/src/filter.js
node filter.spec3 ./submissions/Vladimir\ Menshakov/filter.js
node filter.spec3 ./submissions/Vladimir\ Osipov/filter.js
node filter.spec3 ./submissions/Vladimir\ Prikhozhenko/filter.js
node filter.spec3 ./submissions/Vladimir\ Privalov/filter-y2.js
node filter.spec3 ./submissions/Vladislav\ Nezhutin/filter.js
node filter.spec3 ./submissions/Volodymyr\ Valkiv/final-filter-optimized.js
node filter.spec3 ./submissions/Vyacheslav\ Bazhinov/nfa.js
node filter.spec3 ./submissions/Vyacheslav\ Ryabinin/filter.js
node filter.spec3 ./submissions/Xawn\ Tan/hola.js
node filter.spec3 ./submissions/Yair\ Haimovitch/app5.js
node filter.spec3 ./submissions/Yuri\ Kilochek/filter.js
node filter.spec3 ./submissions/yuri_c/filter.js
node filter.spec3 ./submissions/Yuriy\ Khabarov/filter.js
node filter.spec3 ./submissions/Yury\ Loskot/filter.js
node filter.spec3 ./submissions/Zibx/original.js