'use strict';

function toRegExp(v) {
  var res = '^', i = 0, c, cc, vl = v.length, nwc = 1;

  for (; i < vl;) {
    c = v.charAt(i++);
    cc = c.charCodeAt(0);

    switch (cc) {
      case 42:
        nwc && (res += '.*');
        nwc = 0;
        break;
      case 63:
        res += '.';
        nwc = 1;
        break;
      case 46:
      case 92:
      case 43:
      case 91:
      case 93:
      case 124:
      case 123:
      case 125:
      case 40:
      case 41:
      case 36:
      case 94:
        res += ('\\' + c);
        nwc = 1;
        break;
      default:
        res += c;
        nwc = 1;
        break;
    }
  }

  return new RegExp(res + '$');
}

function compare(r, m) {
  var rl = r.length, ml = m.length, i = 0, r1, m1;

  if (rl !== ml) {
    return 0;
  }

  for (; i < rl;) {
    r1 = r.charCodeAt(i);
    m1 = m.charCodeAt(i);
    if (r1 === m1 || r1 === 63) {
      i++;
      continue;
    }

    return 0;
  }
  return 1;
}

function filter(messages, rules) {
  var results = {};
  var msgKeys = Object.keys(messages);

  for (var r of rules) {
    if (r.from) {
      r.from = toRegExp(r.from);
    }

    if (r.to) {
      r.to = toRegExp(r.to);
    }
  }

  for (var k in messages) {
    results[k] = [];

    for (var r of rules) {
      if (r.from && r.to) {
        if (r.from.test(messages[k].from) && r.to.test(messages[k].to)) {
          results[k].push(r.action);
        }
        continue;
      }

      if (r.from) {
        if (r.from.test(messages[k].from)) {
          results[k].push(r.action);
        }
        continue;
      }

      if (r.to) {
        if (r.to.test(messages[k].to)) {
          results[k].push(r.action);
        }
        continue;
      }
    }
  }

  // var sum = 0;
  // for (var k in results) {
  //   sum += results[k].length;
  // }
  // console.log(sum);

  return results;
}

module.exports = filter;
